﻿using System.Windows.Controls;

namespace OpenBullet
{
    /// <summary>
    /// Logica di interazione per Snowflake.xaml
    /// </summary>
    public partial class Snowflake : UserControl
    {
        public Snowflake()
        {
            InitializeComponent();
        }
    }
}
